globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/TAeyim4-rDcqhdo6PUrQX/_buildManifest.js",
    "static/TAeyim4-rDcqhdo6PUrQX/_ssgManifest.js",
    "static/TAeyim4-rDcqhdo6PUrQX/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0twwouzq09j8x.js",
    "static/chunks/02i7dfk78~t~2.js",
    "static/chunks/0dp-p6eopem5a.js",
    "static/chunks/0iu-2tp5ioy3b.js",
    "static/chunks/turbopack-176o3~omwvak~.js"
  ]
};
