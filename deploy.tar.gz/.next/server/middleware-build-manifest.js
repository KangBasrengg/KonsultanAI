globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/OONLyhvbEIftzZstFEhbS/_buildManifest.js",
    "static/OONLyhvbEIftzZstFEhbS/_ssgManifest.js",
    "static/OONLyhvbEIftzZstFEhbS/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0-hrh_uw98wb_.js",
    "static/chunks/0b397hrdtt4q1.js",
    "static/chunks/0aqpm5mabssqz.js",
    "static/chunks/0uqgm3y7qfyr6.js",
    "static/chunks/128aahewwf1we.js",
    "static/chunks/turbopack-0_rsw0qoytz7w.js"
  ]
};
