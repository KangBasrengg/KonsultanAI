globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/SN73HtBgFV3H9W7TFMYtQ/_buildManifest.js",
    "static/SN73HtBgFV3H9W7TFMYtQ/_ssgManifest.js",
    "static/SN73HtBgFV3H9W7TFMYtQ/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0m97bbjp.vgzu.js",
    "static/chunks/0nsxcf4qh0uns.js",
    "static/chunks/0~rk~iesp54ct.js",
    "static/chunks/0uqgm3y7qfyr6.js",
    "static/chunks/128aahewwf1we.js",
    "static/chunks/turbopack-0xhad6suxiamn.js"
  ]
};
