globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/A5QQlGMzol0pU6mWnDsrf/_buildManifest.js",
    "static/A5QQlGMzol0pU6mWnDsrf/_ssgManifest.js",
    "static/A5QQlGMzol0pU6mWnDsrf/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0twwouzq09j8x.js",
    "static/chunks/02i7dfk78~t~2.js",
    "static/chunks/0o~qwtfsullej.js",
    "static/chunks/0iu-2tp5ioy3b.js",
    "static/chunks/turbopack-0xfkeyny9v9_v.js"
  ]
};
