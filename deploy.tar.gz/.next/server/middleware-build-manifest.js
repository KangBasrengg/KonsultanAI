globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/C19mjO4WNrtw2IVvGSnJs/_buildManifest.js",
    "static/C19mjO4WNrtw2IVvGSnJs/_ssgManifest.js",
    "static/C19mjO4WNrtw2IVvGSnJs/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0m97bbjp.vgzu.js",
    "static/chunks/0acv4k9l2~q08.js",
    "static/chunks/0~rk~iesp54ct.js",
    "static/chunks/0uqgm3y7qfyr6.js",
    "static/chunks/128aahewwf1we.js",
    "static/chunks/turbopack-0ep7546p.648v.js"
  ]
};
