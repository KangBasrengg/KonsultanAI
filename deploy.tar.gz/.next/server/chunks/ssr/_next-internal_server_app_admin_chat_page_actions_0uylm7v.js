module.exports=[821840,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_chat_page_actions_0uylm7v.js.map