module.exports=[59223,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_learning_material_%5Bid%5D_page_actions_0q7i6ud.js.map