module.exports=[2522,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_learning_category_%5Bid%5D_page_actions_04mhild.js.map