var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/checkout/route.js")
R.c("server/chunks/[root-of-the-server]__05b~yu8._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__066zaw2._.js")
R.c("server/chunks/[root-of-the-server]__0xw90f5._.js")
R.c("server/chunks/_next-internal_server_app_api_checkout_route_actions_0b8sqcq.js")
R.m(70797)
module.exports=R.m(70797).exports
