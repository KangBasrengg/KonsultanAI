var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/users/route.js")
R.c("server/chunks/[root-of-the-server]__0nv2ydj._.js")
R.c("server/chunks/_0p.uumx._.js")
R.c("server/chunks/[root-of-the-server]__0xw90f5._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0hp37pu._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_users_route_actions_0fe5t40.js")
R.m(66129)
module.exports=R.m(66129).exports
