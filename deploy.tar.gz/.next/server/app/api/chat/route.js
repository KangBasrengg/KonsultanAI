var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/chat/route.js")
R.c("server/chunks/[root-of-the-server]__09_~.2n._.js")
R.c("server/chunks/_0p.uumx._.js")
R.c("server/chunks/[root-of-the-server]__0xw90f5._.js")
R.c("server/chunks/node_modules_0.xmkfp._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0hp37pu._.js")
R.c("server/chunks/_next-internal_server_app_api_chat_route_actions_0tmcf6..js")
R.m(99280)
module.exports=R.m(99280).exports
