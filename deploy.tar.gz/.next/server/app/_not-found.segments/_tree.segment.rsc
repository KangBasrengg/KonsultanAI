:HL["/_next/static/chunks/0vd~9.p.zt_36.css","style"]
:HL["/_next/static/chunks/0zqzpzwfyq54o.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"/_not-found","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}},"staleTime":300,"buildId":"K3dJGLdY8M5l0eUd97moR"}
