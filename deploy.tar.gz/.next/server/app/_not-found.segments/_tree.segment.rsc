:HL["/_next/static/chunks/0vd~9.p.zt_36.css","style"]
:HL["/_next/static/chunks/0fb3s51idwa0k.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"/_not-found","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}},"staleTime":300,"buildId":"vcTyfNUK3LBGupFeU61jp"}
