1:"$Sreact.fragment"
2:I[339756,["/_next/static/chunks/0d~.ke-0nul80.js","/_next/static/chunks/0.f.kcfm_s8gy.js","/_next/static/chunks/0mcr1kkv687.m.js","/_next/static/chunks/0xh_zc9pn1ehb.js","/_next/static/chunks/0i.l9589uvx0j.js"],"default"]
3:I[837457,["/_next/static/chunks/0d~.ke-0nul80.js","/_next/static/chunks/0.f.kcfm_s8gy.js","/_next/static/chunks/0mcr1kkv687.m.js","/_next/static/chunks/0xh_zc9pn1ehb.js","/_next/static/chunks/0i.l9589uvx0j.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"m-p9RwewvOnYa0nk5D9tS"}
