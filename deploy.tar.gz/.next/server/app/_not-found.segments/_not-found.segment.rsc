1:"$Sreact.fragment"
2:I[339756,["/_next/static/chunks/0uw9e8k5hpztz.js","/_next/static/chunks/00nz~d.bjlpgn.js","/_next/static/chunks/0xh_zc9pn1ehb.js","/_next/static/chunks/0mcr1kkv687.m.js","/_next/static/chunks/0i.l9589uvx0j.js"],"default"]
3:I[837457,["/_next/static/chunks/0uw9e8k5hpztz.js","/_next/static/chunks/00nz~d.bjlpgn.js","/_next/static/chunks/0xh_zc9pn1ehb.js","/_next/static/chunks/0mcr1kkv687.m.js","/_next/static/chunks/0i.l9589uvx0j.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"_g_5hT2BvD-W5yRbyWjT3"}
