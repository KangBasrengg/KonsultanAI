1:"$Sreact.fragment"
2:I[339756,["/_next/static/chunks/0upls1wmupmb..js","/_next/static/chunks/0wuu.1jo7j-f~.js","/_next/static/chunks/0xh_zc9pn1ehb.js","/_next/static/chunks/0mcr1kkv687.m.js","/_next/static/chunks/0i.l9589uvx0j.js"],"default"]
3:I[837457,["/_next/static/chunks/0upls1wmupmb..js","/_next/static/chunks/0wuu.1jo7j-f~.js","/_next/static/chunks/0xh_zc9pn1ehb.js","/_next/static/chunks/0mcr1kkv687.m.js","/_next/static/chunks/0i.l9589uvx0j.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"OONLyhvbEIftzZstFEhbS"}
